%% Coverage, Similarity-based fitness, NS(Nb=15), NS(Nb=2), NS(Nb=1/4*SampleSize),  NS(Nb=HalfSampleSize), NS(Nb=3/4*SampleSize)
data=[84.15333333333334  1572.2709126401182  19.81587116179758  6.9359590820080035  22.45793078883533  26.3637220894115  28.989126661900197  ];
[R,P] = corrcoef(data)
mean(data)
