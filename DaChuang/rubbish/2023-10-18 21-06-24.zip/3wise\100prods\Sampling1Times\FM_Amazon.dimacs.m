%% Coverage, Similarity-based fitness, NS(Nb=15), NS(Nb=2), NS(Nb=1/4*SampleSize),  NS(Nb=HalfSampleSize), NS(Nb=3/4*SampleSize)
data=[83.38533333333336  1564.0765939295036  19.611015255437557  7.081649988973077  22.18089011366417  26.0883853110243  28.80635124681486  ];
[R,P] = corrcoef(data)
mean(data)
